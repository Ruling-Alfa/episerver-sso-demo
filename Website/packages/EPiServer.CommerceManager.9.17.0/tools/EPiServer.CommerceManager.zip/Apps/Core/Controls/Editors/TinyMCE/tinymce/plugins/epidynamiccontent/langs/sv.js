﻿tinyMCE.addI18n('sv.epidynamiccontent', {
    desc: "Dynamiskt innehåll"
});