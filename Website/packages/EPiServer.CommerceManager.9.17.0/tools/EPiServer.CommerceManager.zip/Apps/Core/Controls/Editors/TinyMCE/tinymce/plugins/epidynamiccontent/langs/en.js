﻿tinyMCE.addI18n('en.epidynamiccontent', {
    desc: "Dynamic Content"
});