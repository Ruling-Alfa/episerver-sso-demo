require({cache:{
'url:epi-ecf-ui/widget/templates/VariantEdit.html':"﻿<div>\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-cms/contentediting/StandardToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div data-dojo-attach-point=\"notificationBar\" data-dojo-type=\"epi-cms/contentediting/NotificationBar\" data-dojo-props=\"region:'top'\"></div>\r\n\r\n    <div data-dojo-type=\"dijit/layout/ContentPane\" data-dojo-attach-point=\"contentPane\" class=\"epi-view-container\">\r\n        <h1>${resources.title}</h1>\r\n        <div data-dojo-attach-point=\"collectionList\" data-dojo-type=\"epi-ecf-ui/contentediting/editors/VariantCollectionEditor\"></div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/VariantEdit", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

// EPi Framework
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/dnd/Target",

// cms
    "epi-cms/widget/Breadcrumb",
    "epi-cms/widget/BreadcrumbCurrentItem",

// commerce
    "../contentediting/editors/VariantCollectionEditor",
    "./_RelationViewBase",

// Resources
    "dojo/text!./templates/VariantEdit.html",
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.variantcollectioneditor",
// Widgets in the template
    "epi-cms/contentediting/NotificationBar",
    "epi-cms/contentediting/StandardToolbar"
], function (
// dojo
    declare,
    lang,
    topic,

// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

// EPi Framework
    _ModelBindingMixin,
    Target,

// CMS
    Breadcrumb,
    BreadcrumbCurrentItem,

// commerce
    VariantCollectionEditor,
    _RelationViewBase,

// Resources
    template,
    resources
) {

    return declare([_RelationViewBase, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
        // summary:
        //    Represents the widget to edit variants.
        // tags:
        //    public
        templateString: template,

        resources: resources,

        contentPane: this.contentPane,

        postCreate: function() {
            this.inherited(arguments);
            this.own(this.collectionList.on("list-error", lang.hitch(this, function(event){
                this.notificationBar.add({content: event.errorText});
            })));
        },

        updateView: function (data, context) {
            // summary:
            //		Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //		protected

            this.notificationBar.clear();
            this.inherited(arguments);
            this.set("value", context.id);
        },

        _setValueAttr: function (value) {
            this.collectionList.set("value", value);
        }
    });
});
